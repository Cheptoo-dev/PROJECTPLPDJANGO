from django.apps import AppConfig


class EcommerceplpConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ecommerceplp'
